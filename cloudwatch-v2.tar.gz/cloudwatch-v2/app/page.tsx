'use client';

import { useEffect, useState, useRef } from 'react';
import {
  Card,
  Metric,
  Text,
  Title,
  Badge,
  Grid,
  Flex,
  TextInput,
  Button,
} from '@tremor/react';
import { Search, RefreshCw, Play, Pause } from 'lucide-react';
import { ThemeToggle } from '@/components/ThemeToggle';
import { getInstances, getDashboardUrl } from '@/lib/api';
import type { Instance } from '@/types';

export default function Dashboard() {
  const [instances, setInstances] = useState<Instance[]>([]);
  const [filteredInstances, setFilteredInstances] = useState<Instance[]>([]);
  const [criticalCount, setCriticalCount] = useState(0);
  const [dashboardUrl, setDashboardUrl] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAutoScrolling, setIsAutoScrolling] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  const instancesContainerRef = useRef<HTMLDivElement>(null);
  const scrollIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [urlData, instancesData] = await Promise.all([
          getDashboardUrl(),
          getInstances(),
        ]);

        setDashboardUrl(urlData.url);
        setInstances(instancesData.instances);
        setFilteredInstances(instancesData.instances);
        setCriticalCount(instancesData.critical);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30s

    return () => clearInterval(interval);
  }, []);

  // Update time
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Search filter
  useEffect(() => {
    const filtered = instances.filter(
      (inst) =>
        inst.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inst.ip.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inst.instance_id.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredInstances(filtered);
  }, [searchQuery, instances]);

  // Auto-scroll
  useEffect(() => {
    if (isAutoScrolling && instancesContainerRef.current) {
      let direction = 1;
      let currentScroll = 0;

      scrollIntervalRef.current = setInterval(() => {
        const container = instancesContainerRef.current;
        if (!container) return;

        const maxScroll = container.scrollHeight - container.clientHeight;

        if (direction === 1) {
          currentScroll += 1;
          if (currentScroll >= maxScroll) {
            currentScroll = maxScroll;
            direction = -1;
          }
        } else {
          currentScroll -= 1;
          if (currentScroll <= 0) {
            currentScroll = 0;
            direction = 1;
          }
        }

        container.scrollTop = currentScroll;
      }, 20);
    } else {
      if (scrollIntervalRef.current) {
        clearInterval(scrollIntervalRef.current);
        scrollIntervalRef.current = null;
      }
    }

    return () => {
      if (scrollIntervalRef.current) {
        clearInterval(scrollIntervalRef.current);
      }
    };
  }, [isAutoScrolling]);

  const formatTime = (date: Date, timezone: string) => {
    return date.toLocaleTimeString('en-US', {
      timeZone: timezone,
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const handleRefresh = async () => {
    try {
      const instancesData = await getInstances();
      setInstances(instancesData.instances);
      setFilteredInstances(instancesData.instances);
      setCriticalCount(instancesData.critical);
    } catch (error) {
      console.error('Error refreshing:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-gray-200 dark:border-gray-800 
                       bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Logo & Brand */}
            <div className="flex items-center gap-3 sm:gap-4">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg overflow-hidden flex-shrink-0">
                <img 
                  src="https://i.ibb.co/ZpCv7rFS/logo.png" 
                  alt="Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="hidden sm:block">
                <Title className="!text-lg sm:!text-xl !mb-0">AWS CloudWatch Monitor</Title>
                <Text className="!text-xs text-aws-cyan dark:text-aws-cyan">
                  v2.0 • Infrastructure Monitoring
                </Text>
              </div>
            </div>

            {/* Status & Time */}
            <div className="flex items-center gap-2 sm:gap-4">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg
                            bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <Text className="!text-xs font-semibold text-green-700 dark:text-green-400">
                  Operational
                </Text>
              </div>

              <div className="hidden lg:flex items-center gap-3 px-3 py-1.5 rounded-lg
                            bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <Text className="!text-[10px] font-bold text-gray-500 dark:text-gray-400">PKT</Text>
                  <Text className="!text-sm font-mono font-bold text-aws-cyan">
                    {formatTime(currentTime, 'Asia/Karachi')}
                  </Text>
                </div>
                <div className="w-px h-8 bg-gray-300 dark:bg-gray-600" />
                <div className="text-center">
                  <Text className="!text-[10px] font-bold text-gray-500 dark:text-gray-400">EST</Text>
                  <Text className="!text-sm font-mono font-bold text-aws-cyan">
                    {formatTime(currentTime, 'America/New_York')}
                  </Text>
                </div>
              </div>

              <ThemeToggle />
              
              <Button
                size="xs"
                variant="secondary"
                icon={RefreshCw}
                onClick={handleRefresh}
                className="hidden sm:flex"
              >
                Refresh
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
        <Grid numItemsSm={1} numItemsLg={3} className="gap-4 sm:gap-6">
          {/* CloudWatch Dashboard - Takes 2 columns on large screens */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="!p-0 overflow-hidden">
              <div className="p-4 border-b border-gray-200 dark:border-gray-800 
                            flex items-center justify-between">
                <Title>CloudWatch Dashboard</Title>
              </div>
              <div className="relative" style={{ height: 'calc(100vh - 280px)' }}>
                <iframe
                  src={dashboardUrl}
                  className="w-full h-full border-0"
                  title="CloudWatch Dashboard"
                />
              </div>
            </Card>
          </div>

          {/* Sidebar - Instance Monitor */}
          <div className="space-y-4">
            {/* Critical Alert Card */}
            <Card
              className="!bg-gradient-to-br from-red-50 to-red-100 
                       dark:from-red-950/30 dark:to-red-900/20
                       !border-red-200 dark:!border-red-800"
              decoration="top"
              decorationColor="red"
            >
              <Flex alignItems="start" className="gap-3">
                <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-red-100 dark:bg-red-900/40
                              flex items-center justify-center border-2 border-red-300 dark:border-red-700">
                  <Text className="!text-2xl !font-black text-red-600 dark:text-red-400">!</Text>
                </div>
                <div className="flex-1">
                  <Text className="!text-xs !font-bold !uppercase tracking-wider 
                                 text-red-600 dark:text-red-400 !mb-1">
                    Critical Instances
                  </Text>
                  <Metric className="!text-red-600 dark:!text-red-400">
                    {criticalCount}
                  </Metric>
                  <Text className="!text-xs text-red-600/70 dark:text-red-400/70 !mt-1">
                    Require Attention
                  </Text>
                </div>
              </Flex>
            </Card>

            {/* Search */}
            <TextInput
              icon={Search}
              placeholder="Search by name or IP..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />

            {/* Instances List */}
            <Card className="!p-0">
              <div className="p-4 border-b border-gray-200 dark:border-gray-800
                            flex items-center justify-between">
                <Title className="!text-base">Active Instances ({filteredInstances.length})</Title>
                <Button
                  size="xs"
                  variant={isAutoScrolling ? 'primary' : 'secondary'}
                  icon={isAutoScrolling ? Pause : Play}
                  onClick={() => setIsAutoScrolling(!isAutoScrolling)}
                >
                  {isAutoScrolling ? 'Pause' : 'Scroll'}
                </Button>
              </div>

              <div
                ref={instancesContainerRef}
                className="overflow-y-auto custom-scrollbar p-4 space-y-3"
                style={{ height: 'calc(100vh - 520px)', minHeight: '400px' }}
              >
                {filteredInstances.length === 0 ? (
                  <Text className="text-center py-8">No instances found</Text>
                ) : (
                  filteredInstances.map((instance, index) => (
                    <Card
                      key={instance.instance_id}
                      className={`!p-4 transition-all duration-300 hover:scale-[1.02]
                        ${instance.status === 'CRITICAL' 
                          ? '!border-l-4 !border-l-red-500 dark:!border-l-red-500' 
                          : '!border-l-4 !border-l-transparent'
                        } hover:!border-l-aws-cyan`}
                      style={{
                        animation: `fadeIn 0.3s ease-out ${index * 0.05}s both`,
                      }}
                    >
                      <Flex justifyContent="between" alignItems="start" className="!mb-3">
                        <div className="flex-1 min-w-0">
                          <Title className="!text-sm sm:!text-base !mb-1 truncate">
                            {instance.name}
                          </Title>
                          <Text className="!text-xs font-mono text-gray-500 dark:text-gray-400 truncate">
                            {instance.instance_id}
                          </Text>
                        </div>
                        <Badge
                          color={instance.status === 'CRITICAL' ? 'red' : 'green'}
                          className="flex-shrink-0 ml-2"
                        >
                          {instance.status}
                        </Badge>
                      </Flex>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-gray-50 dark:bg-gray-800/50 rounded p-2">
                          <Text className="!text-[10px] !font-bold !uppercase tracking-wide 
                                         text-gray-500 dark:text-gray-400 !mb-1">
                            IP Address
                          </Text>
                          <Text className="!text-xs font-mono font-semibold text-aws-cyan">
                            {instance.ip}
                          </Text>
                        </div>
                        <div className={`rounded p-2 ${
                          instance.status === 'CRITICAL'
                            ? 'bg-red-50 dark:bg-red-950/30'
                            : 'bg-gray-50 dark:bg-gray-800/50'
                        }`}>
                          <Text className="!text-[10px] !font-bold !uppercase tracking-wide 
                                         text-gray-500 dark:text-gray-400 !mb-1">
                            Metric
                          </Text>
                          <Text className={`!text-xs font-mono font-semibold ${
                            instance.status === 'CRITICAL'
                              ? 'text-red-600 dark:text-red-400'
                              : 'text-aws-cyan'
                          }`}>
                            {instance.usage.replace('Monitored - ', '')}
                          </Text>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </Card>
          </div>
        </Grid>
      </main>

      <style jsx global>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
