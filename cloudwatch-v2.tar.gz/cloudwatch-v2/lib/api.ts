import axios from 'axios';
import type { DashboardUrlResponse, InstancesResponse } from '@/types';

// Configure API base URL
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || '';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
});

export const getDashboardUrl = async (): Promise<DashboardUrlResponse> => {
  const response = await api.get<DashboardUrlResponse>('/api/dashboard/url');
  return response.data;
};

export const getInstances = async (): Promise<InstancesResponse> => {
  const response = await api.get<InstancesResponse>('/api/instances');
  return response.data;
};

export const healthCheck = async (): Promise<{ status: string; service: string }> => {
  const response = await api.get('/health');
  return response.data;
};
