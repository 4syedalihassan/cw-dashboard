export interface Instance {
  name: string;
  ip: string;
  status: 'CRITICAL' | 'WARNING' | 'HEALTHY';
  usage: string;
  instance_id: string;
}

export interface InstancesResponse {
  instances: Instance[];
  total: number;
  critical: number;
  error?: string;
}

export interface DashboardUrlResponse {
  url: string;
  dashboard_name: string;
  region: string;
}
