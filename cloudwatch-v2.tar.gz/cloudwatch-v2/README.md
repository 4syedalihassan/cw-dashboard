# AWS CloudWatch Monitor v2.0

Modern, responsive React dashboard for AWS CloudWatch monitoring built with Next.js and Tremor.

## Features

- **Tremor UI Components** - Purpose-built dashboard components
- **Light/Dark Theme** - Automatic theme switching with system preference
- **Fully Responsive** - Mobile to 32" display optimization
- **Real-time Updates** - Auto-refresh every 30 seconds
- **Auto-scroll** - Smooth automatic scrolling for NOC displays
- **Search/Filter** - Quick instance lookup
- **CloudWatch Integration** - Direct AWS CloudWatch API integration

## Tech Stack

- **Framework:** Next.js 14 (App Router)
- **UI Library:** Tremor (dashboard components)
- **Styling:** Tailwind CSS
- **Theme:** next-themes
- **Language:** TypeScript
- **Icons:** Lucide React
- **HTTP Client:** Axios

## Prerequisites

- Node.js 18+ 
- npm or yarn
- Flask backend running (from v1.0)

## Installation

### 1. Install Dependencies

```bash
cd cloudwatch-v2
npm install
```

### 2. Configure Environment

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:

```env
# Leave empty if Next.js and Flask run on same domain
NEXT_PUBLIC_API_URL=

# For development with separate ports:
# NEXT_PUBLIC_API_URL=http://localhost:5000
```

### 3. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Production Deployment on Bitnami Lightsail

### Option 1: Static Export (Simplest)

Next.js can export to static HTML/JS and be served by existing Nginx:

**1. Update `next.config.js`:**

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  images: {
    unoptimized: true,
  },
  // Remove rewrites for static export
};
```

**2. Build and export:**

```bash
npm run build
# Creates 'out' directory with static files
```

**3. Deploy to server:**

```bash
# Copy to server
scp -r out/* bitnami@YOUR_IP:/opt/bitnami/apps/aws-monitor/static/

# Update Flask app.py to serve Next.js build
```

Update Flask route:

```python
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != "" and os.path.exists(f"static/{path}"):
        return send_from_directory('static', path)
    else:
        return send_from_directory('static', 'index.html')
```

**4. Restart Flask:**

```bash
sudo systemctl restart aws-monitor
```

### Option 2: Full Next.js Server (Advanced)

Run Next.js as a separate service on port 3000 with Nginx reverse proxy.

**1. Build for production:**

```bash
npm run build
```

**2. Upload to server:**

```bash
# Create directory
ssh bitnami@YOUR_IP
sudo mkdir -p /opt/bitnami/apps/cloudwatch-v2
cd /opt/bitnami/apps/cloudwatch-v2

# Upload files (from local machine)
scp -r package.json package-lock.json next.config.js tsconfig.json \
       app components lib types public .env.local \
       bitnami@YOUR_IP:/opt/bitnami/apps/cloudwatch-v2/
```

**3. Install dependencies on server:**

```bash
cd /opt/bitnami/apps/cloudwatch-v2
npm install --production
```

**4. Create systemd service:**

```bash
sudo nano /etc/systemd/system/cloudwatch-v2.service
```

```ini
[Unit]
Description=AWS CloudWatch Monitor v2.0
After=network.target

[Service]
Type=simple
User=bitnami
WorkingDirectory=/opt/bitnami/apps/cloudwatch-v2
Environment="NODE_ENV=production"
Environment="PORT=3000"
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**5. Start service:**

```bash
sudo systemctl daemon-reload
sudo systemctl enable cloudwatch-v2
sudo systemctl start cloudwatch-v2
```

**6. Update Nginx:**

```nginx
# Add to /opt/bitnami/nginx/conf/server_blocks/aws-monitor.conf

location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
}

# Keep Flask API proxied separately
location /api/ {
    proxy_pass http://127.0.0.1:5000;
    # ... proxy settings
}
```

## Customization

### Change Theme Colors

Edit `tailwind.config.js`:

```javascript
theme: {
  extend: {
    colors: {
      'aws-cyan': '#YOUR_COLOR',
    },
  },
}
```

### Adjust Auto-scroll Speed

In `app/page.tsx`, find `startAutoScroll` interval:

```typescript
scrollIntervalRef.current = setInterval(() => {
  currentScroll += 1;  // Change this (1 = slow, 3 = fast)
}, 20);  // Change this (20ms = smooth, 50ms = slower)
```

### Update Logo

Replace in `app/page.tsx`:

```tsx
<img 
  src="https://i.ibb.co/ZpCv7rFS/logo.png"  // Your logo URL
  alt="Logo"
/>
```

Or use local file in `public/` folder:

```tsx
<img src="/logo.png" alt="Logo" />
```

## Responsive Breakpoints

The dashboard adapts across devices:

- **Mobile** (<640px): Single column, stacked layout
- **Tablet** (640-1024px): Sidebar stacks below dashboard
- **Desktop** (1024-1280px): 2-column grid
- **Large Display** (1280px+): 3-column grid (dashboard takes 2 cols)

## API Endpoints

The React app expects these Flask endpoints:

- `GET /api/dashboard/url` - CloudWatch dashboard URL
- `GET /api/instances` - Instance list with metrics
- `GET /health` - Health check

## Development

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Type check
npm run type-check

# Lint
npm run lint
```

## Folder Structure

```
cloudwatch-v2/
├── app/
│   ├── globals.css          # Global styles
│   ├── layout.tsx           # Root layout with theme
│   └── page.tsx             # Main dashboard
├── components/
│   └── ThemeToggle.tsx      # Light/dark switch
├── lib/
│   └── api.ts               # API client
├── types/
│   └── index.ts             # TypeScript types
├── public/                  # Static assets
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── next.config.js
```

## Troubleshooting

### API calls fail

- Check Flask backend is running: `sudo systemctl status aws-monitor`
- Verify NEXT_PUBLIC_API_URL in `.env.local`
- Check browser console for CORS errors

### Theme not persisting

- next-themes saves to localStorage automatically
- Check browser localStorage: `localStorage.getItem('theme')`

### Auto-scroll not smooth

- Increase interval time for slower scroll
- Reduce scroll increment for smoother movement
- Check browser performance in DevTools

## License

MIT

## Support

For issues or questions, check the deployment guide in `AWS-Monitor-Setup-Guide.docx`
